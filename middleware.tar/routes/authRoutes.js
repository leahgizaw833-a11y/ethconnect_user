const express = require('express');
const authController = require('../controllers/authController');
const { body } = require('express-validator');
const router = express.Router();
const { isValidPhone } = require('../utils/phoneUtils');
const { authenticateToken } = require('../middleware/auth');
const { requireRole } = require('../middleware/roles');
const { handleValidationErrors } = require('../middleware/validation');
// Admin/debug controllers removed for SMS resend cleanup

router.post('/register', [
  body('username').optional().trim().isLength({ min: 3, max: 120 }),
  body('email').optional().isEmail(),
  body('phone').optional().custom(value => { if (value && !isValidPhone(value)) throw new Error('Invalid phone'); return true; }),
  body('password').isLength({ min: 6 }),
  body('role').optional().isIn(['employer', 'employee', 'doctor', 'user']).withMessage('Invalid role'),
  handleValidationErrors
], authController.register);

router.post('/login', [
  body('email').isEmail(),
  body('password').notEmpty(),
  handleValidationErrors
], authController.login);

// === OTP routes (duplicates removed) ===
router.post('/otp/request', [
  body('phone').custom(value => { if (!isValidPhone(value)) throw new Error('Invalid phone'); return true; }),
  handleValidationErrors
], authController.requestOTP);

router.post('/otp/verify', [
  body('phone').custom(value => { if (!isValidPhone(value)) throw new Error('Invalid phone'); return true; }),
  body('otp').isLength({ min: 6, max: 6 }),
  handleValidationErrors
], authController.verifyOTP);

router.post('/otp/login', 
  authenticateToken,
  [
    body('phone').custom(value => { if (!isValidPhone(value)) throw new Error('Invalid phone'); return true; }),
    handleValidationErrors
  ], 
  authController.loginWithOtp
);
// === end OTP routes ===

router.post('/refresh-token', [
  body('refreshToken').notEmpty(),
  handleValidationErrors
], authController.refreshToken);

router.get('/me', authenticateToken, authController.getCurrentUser);

// === Admin routes ===
router.post('/admin/login', [
  body('email').isEmail(),
  body('password').notEmpty(),
  handleValidationErrors
], authController.adminLogin);

router.post('/admin/create', 
  authenticateToken,
  requireRole('admin'),
  [
    body('username').trim().isLength({ min: 3, max: 120 }),
    body('email').isEmail(),
    body('password').isLength({ min: 6 }),
    body('phone').optional().custom(value => { if (value && !isValidPhone(value)) throw new Error('Invalid phone'); return true; }),
    handleValidationErrors
  ], 
  authController.createAdmin
);
// === end Admin routes ===

module.exports = router;
